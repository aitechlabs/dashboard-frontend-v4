export default function Home() {
  return (
    <div className="min-h-screen bg-darkbg text-white flex flex-col items-center justify-center">
      <h1 className="text-4xl font-bold">Welcome to Master Browser Dashboard</h1>
      <p className="mt-4 text-gray-300">Dark mode ready. Hosted on Vercel.</p>
    </div>
  );
}