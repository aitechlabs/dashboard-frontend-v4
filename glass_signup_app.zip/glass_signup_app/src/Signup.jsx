import React from "react";

export default function Signup() {
  return (
    <div className="flex items-center justify-center min-h-screen p-4">
      <div className="backdrop-blur-lg bg-white/10 p-8 rounded-2xl shadow-2xl w-full max-w-md border border-white/20">
        <h2 className="text-2xl font-bold mb-6 text-center text-white">Sign Up</h2>
        <form className="space-y-4">
          <input
            type="text"
            placeholder="First Name"
            className="w-full p-3 rounded-lg bg-gray-900/60 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-white/40"
          />
          <input
            type="text"
            placeholder="Last Name"
            className="w-full p-3 rounded-lg bg-gray-900/60 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-white/40"
          />
          <input
            type="email"
            placeholder="Email"
            className="w-full p-3 rounded-lg bg-gray-900/60 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-white/40"
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full p-3 rounded-lg bg-gray-900/60 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-white/40"
          />
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-gray-700 via-gray-600 to-gray-700 text-white p-3 rounded-lg hover:opacity-90 transition"
          >
            Create Account
          </button>
        </form>
      </div>
    </div>
  );
}
