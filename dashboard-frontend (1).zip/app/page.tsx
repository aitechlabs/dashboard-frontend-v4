export default function Home() {
  return (
    <main style={{
      display: "flex",
      height: "100vh",
      justifyContent: "center",
      alignItems: "center",
      background: "linear-gradient(135deg, #2b2b2b, #3a3a3a)"
    }}>
      <h1 style={{ color: "white", fontSize: "2rem" }}>
        🚀 Ai-TechLabs Dashboard
      </h1>
    </main>
  );
}
